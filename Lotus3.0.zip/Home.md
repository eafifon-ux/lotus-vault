# - Home

| [[📁 Boomerang/Capture|Capture]] | [[📁 Boomerang/Events|Events]] | [[📁 Boomerang/To Do|ToDo]] | [[📁 Boomerang/Shopping|Shopping]] |
| -- | -- | -- | -- |

<br><br>

| [🗓️ Today](https://www.gpc364.com/2026/03/holidays.html?m=1) | [💬 Chat](https://eafifon-ux.github.io/Matka/) | [[📁 Boomerang/📿 Tracker::📿 Tracker]]  | [☯️ Balance](https://www.gpc364.com/2025/12/calendar_95.html)  | [📅 EZDates](https://www.gpc364.com/2026/01/ez-dates.html) | [🌙 Moon](https://www.gpc364.com/2026/01/my-moon.html) |
| :---: | :---: |---|---| :---: | :---: |

<br><br>

| Q1 | Q2 | Q3 | Q4 |
| :--: | :--: | :--: | :--: |
| [[📁 Boomerang/Unspring|🟠 Unspring]] <br><br> | [[📁 Boomerang/Quadsum|🟠 Quadsum]] <br><br> | [[📁 Boomerang/Sepafall|🟠 Sepafall]] <br><br> | [[📁 Boomerang/Dekawint|🟠 Dekawint]] <br><br> |
| [[📁 Boomerang/Duspring|🌺 Duspring]] <br><br> | [[📁 Boomerang/Fivesum|🌺 Fivesum]] <br><br> | [[📁 Boomerang/Oktafall|🌺 Oktafall]] <br><br> | [[📁 Boomerang/Elvawint|🌺 Elvawint]] <br><br> |
| [[📁 Boomerang/Trispring|🟢 Trispring]] <br><br> | [[📁 Boomerang/Sixsum|🟢 Sixsum]] <br><br> | [[📁 Boomerang/Novafall|🟢 Novafall]] <br><br> | [[📁 Boomerang/Dozawint|🟢 Dozawint]] <br><br> |

<br><br>

| **[[📁 Boomerang/1|1]]** <br><br> | [[📁 Boomerang/2|2]] <br><br> | [[📁 Boomerang/3|3]] <br><br> | [[📁 Boomerang/4|4]] <br><br> | [[📁 Boomerang/5|5]] <br><br> | [[📁 Boomerang/6|6]] <br><br> | [[📁 Boomerang/7|7]] <br><br> |
| -- | -- | -- | -- | -- | -- | -- |
| **[[📁 Boomerang/8|8]]** <br><br> | [[📁 Boomerang/9|9]] <br><br> | [[📁 Boomerang/10|10]] <br><br> | [[📁 Boomerang/11|11]] <br><br> | [[📁 Boomerang/12|12]] <br><br> | [[📁 Boomerang/13|13]] <br><br> | [[📁 Boomerang/14|14]] <br><br> |
| **[[📁 Boomerang/15|15]]** <br><br> | [[📁 Boomerang/16|16]] <br><br> | [[📁 Boomerang/17|17]] <br><br> | [[📁 Boomerang/18|18]] <br><br> | [[📁 Boomerang/19|19]] <br><br> | [[📁 Boomerang/20|20]] <br><br> | [[📁 Boomerang/21|21]] <br><br> |
| **[[📁 Boomerang/22|22]]** <br><br> | [[📁 Boomerang/23|23]] <br><br> | [[📁 Boomerang/24|24]] <br><br> | [[📁 Boomerang/25|25]] <br><br> | [[📁 Boomerang/26|26]] <br><br> | [[📁 Boomerang/27|27]] <br><br> | [[📁 Boomerang/28|28]] <br><br> |
| **[[📁 Boomerang/29|29]]** <br><br> | [[📁 Boomerang/30|30]] <br><br> | [[📁 Boomerang/31|31]] <br><br> | | | | |

<br><br><br>

## - Get Started

You’re already inside Lotus — start using it right now.

- Click any link above (Today, Capture, Events, ToDo…) to begin  
- Create new pages: type [[New Page]] → highlight → click 🗒️ icon in toolbar  
- Use the bottom toolbar for bold, colors, tables, checkboxes, date stamps, export…

**Optional – Offline version (full vault)**

To download Lotus.zip reliably:

1. Click Load Full Vault in the left sidebar

Then read: [[📁 Boomerang/Manual|Manual]]

