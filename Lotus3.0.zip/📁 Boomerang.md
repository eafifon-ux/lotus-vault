# Annual
| [[📁 Boomerang/Q1|Q1]]   | [[📁 Boomerang/Q2|Q2]]   | [[📁 Boomerang/Q3|Q3]]  | [[📁 Boomerang/Q4|Q4]]  |
|----|----|---|---|

- [ ] Spring Cleaning