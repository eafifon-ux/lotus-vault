# Septet

[[📁 Boomerang/Events|🗓️ Events]]
***
# Septet

[[📁 Boomerang/FR|🟠 FR]] - 
[[📁 Boomerang/FV|🟤 FV]] - 
[[📁 Boomerang/SS|🌺 SS]] - 
[[📁 Boomerang/SH|⚫ SH]] - Rest 
[[📁 Boomerang/UN|🟢 UN]] - 
[[📁 Boomerang/DU|🔵 DU]] - 
[[📁 Boomerang/TR|🟣 TR]] -  

---

| Day Dot | GPC | Gregorian |
| -- | -- | -- |
| 🟠 | Fourday | Wednesday |
| 🟤 | Fiveday | Thursday |
| 🌺 | Sesday | Friday |
| ⚫ | Shabat | Saturday |
| 🟢 | Unday | Sunday |
| 🔵 | Duday | Monday |
| 🟣 | Threeday | Tuesday |

| [[📁 Boomerang/Monthly|Month]] | [[📁 Boomerang/Quarterly|Quarter]] | [[📁 Boomerang/Annual|Annual]]| [[📁 Boomerang/Equinoxes|Equinox]]| [[📁 Boomerang/Solstices|Solstice]] |
| -- | -- | -- | -- | -- |