# Shopping

[[📁 Boomerang/To Do|To Do]]
- [ ] eggs 
- [ ] bread
- [ ] butter 

[[📁 Boomerang/Events|Events]]