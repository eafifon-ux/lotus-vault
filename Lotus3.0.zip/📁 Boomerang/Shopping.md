# Shopping

| [[📁 Boomerang/To Do|To Do]] | [[📁 Boomerang/Notes|Notes]] |
| --- | --- |

- [ ] eggs 
- [ ] bread
- [ ] butter 

[[📁 Boomerang/Events|Events]]