# Two Behind

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/One Behind|1️⃣🅱️]] | [[📁 Boomerang/Three Behind|3️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|-----------------|--------|
| 1       | 💤 23 |
| 2       | 💤 24 |
| 🟡 3    | 1 🟡  |
| 🟡 4    | 2 🟡  |
| 🟡 5    | 3 🟡  |
| 🟡 6    | 4 🟡  |
| 🟡 7    | 5 🟡  |
| 🟡 8    | 6 🟡  |
| 🟡 9    | 7 🟡  |
| 🟡 10   | 8 🟡  |
| 🟡 11   | 9 🟡  |
| 🟡 12   | 10 🟡 |
| 🟡 13   | 11 🟡 |
| 🟡 14   | 12 🟡 |
| 🟡 15   | 13 🟡 |
| 🟡 16   | 14 🟡 |
| 17 💤   | 15 |
| 18 💤   | 16 |
| 19 💤   | 💤 17 |
| 20 💤   | 💤 18 |
| 21 💤   | 💤 19 |
| 22 💤   | 💤 20 |
| 23 💤   | 💤 21 |
| 24 💤   | 💤 22 |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 7       | 💤 5  |
| 8       | 💤 6  |
| 🟡 9    | 7 🟡  |
| 🟡 10   | 8 🟡  |
| 🟡 11   | 9 🟡  |
| 🟡 12   | 10 🟡 |
| 🟡 13   | 11 🟡 |
| 🟡 14   | 12 🟡 |
| 🟡 15   | 13 🟡 |
| 🟡 16   | 14 🟡 |
| 🟡 17   | 15 🟡 |
| 🟡 18   | 16 🟡 |
| 🟡 19   | 17 🟡 |
| 🟡 20   | 18 🟡 |
| 🟡 21   | 19 🟡 |
| 🟡 22   | 20 🟡 |
| 23 💤   | 21    |
| 24 💤   | 22    |
| 1 💤    | 💤 23 |
| 2 💤    | 💤 24 |
| 3 💤    | 💤 1  |
| 4 💤    | 💤 2  |
| 5 💤    | 💤 3  |
| 6 💤    | 💤 4  |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)