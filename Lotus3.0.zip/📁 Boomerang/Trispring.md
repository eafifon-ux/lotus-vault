# Trispring

[[📁 Boomerang/Duspring|🌼 DS]] [[Home|  🏠  ]] [[📁 Boomerang/Quadsum|☀️ QS]]

| [[📁 Boomerang/FR|🟠 W]] | [[📁 Boomerang/FV|🟤 TH]] | [[📁 Boomerang/SS|🌺 F]] | [[📁 Boomerang/SH|⚫ S]] | [[📁 Boomerang/UN|🟢 SN]] | [[📁 Boomerang/DU|🔵 M]] | [[📁 Boomerang/TR|🟣 T]] |
| -- | -- | -- | -- | -- | -- | -- |
| | | | | ==green:**[[📁 Boomerang/1|1]]**<br><br>*061*<br><br>MAY 17 ==| **[[📁 Boomerang/Q1#D061|061]]**<br><br>*[[📁 Boomerang/Q1#D062|062]]*<br><br>MAY 18 | **[[📁 Boomerang/3|3]]**<br><br>*[[📁 Boomerang/Q1#D063|063]]*<br><br>MAY 19 |
| **[[📁 Boomerang/4|4]]**<br><br>*[[📁 Boomerang/Q1#D064|064]]*<br><br>MAY 20 | **[[📁 Boomerang/5|5]]**<br><br>*[[📁 Boomerang/Q1#D065|065]]*<br><br>MAY 21 | **[[📁 Boomerang/6|6]]**<br><br>*[[📁 Boomerang/Q1#D066|066]]*<br><br>MAY 22 | **[[📁 Boomerang/7|7]]**<br><br>*[[📁 Boomerang/Q1#D067|067]]*<br><br>MAY 23 | ==green:**[[📁 Boomerang/8|8]]**<br><br>*[[📁 Boomerang/Q1#D068|068]]*<br><br>MAY 24 ==| **[[📁 Boomerang/9|9]]**<br><br>*[[📁 Boomerang/Q1#D069|069]]*<br><br>MAY 25 | **[[📁 Boomerang/10|10]]**<br><br>*[[📁 Boomerang/Q1#D070|070]]*<br><br>MAY 26 |
| **[[📁 Boomerang/11|11]]**<br><br>*[[📁 Boomerang/Q1#D071|071]]*<br><br>MAY 27 | **[[📁 Boomerang/12|12]]**<br><br>*[[📁 Boomerang/Q1#D072|072]]*<br><br>MAY 28 | **[[📁 Boomerang/13|13]]**<br><br>*[[📁 Boomerang/Q1#D073|073]]*<br><br>MAY 29 | **[[📁 Boomerang/14|14]]**<br><br>*[[📁 Boomerang/Q1#D074|074]]*<br><br>MAY 30 | ==green:**[[📁 Boomerang/15|15]]**<br><br>*[[📁 Boomerang/Q1#D075|075]]*<br><br>MAY 31 ==| **[[📁 Boomerang/16|16]]**<br><br>*[[📁 Boomerang/Q1#D076|076]]*<br><br>JUN 1 | **[[📁 Boomerang/17|17]]**<br><br>*[[📁 Boomerang/Q1#D077|077]]*<br><br>JUN 2 |
| **[[📁 Boomerang/18|18]]**<br><br>*[[📁 Boomerang/Q1#D078|078]]*<br><br>JUN 3 | **[[📁 Boomerang/19|19]]**<br><br>*[[📁 Boomerang/Q1#D079|079]]*<br><br>JUN 4 | **[[📁 Boomerang/20|20]]**<br><br>*[[📁 Boomerang/Q1#D080|080]]*<br><br>JUN 5 | **[[📁 Boomerang/21|21]]**<br><br>*[[📁 Boomerang/Q1#D081|081]]*<br><br>JUN 6 | ==green:**[[📁 Boomerang/22|22]]**<br><br>*[[📁 Boomerang/Q1#D082|082]]*<br><br>JUN 7 ==| **[[📁 Boomerang/23|23]]**<br><br>*[[📁 Boomerang/Q1#D083|083]]*<br><br>JUN 8 | **[[📁 Boomerang/24|24]]**<br><br>*[[📁 Boomerang/Q1#D084|084]]*<br><br>JUN 9 |
| **[[📁 Boomerang/25|25]]**<br><br>*[[📁 Boomerang/Q1#D085|085]]*<br><br>JUN 10 | **[[📁 Boomerang/26|26]]**<br><br>*[[📁 Boomerang/Q1#D086|086]]*<br><br>JUN 11 | **[[📁 Boomerang/27|27]]**<br><br>*[[📁 Boomerang/Q1#D087|087]]*<br><br>JUN 12 | **[[📁 Boomerang/28|28]]**<br><br>*[[📁 Boomerang/Q1#D088|088]]*<br><br>JUN 13 | ==green:**[[📁 Boomerang/29|29]]**<br><br>*[[📁 Boomerang/Q1#D089|089]]*<br><br>JUN 14 ==| **[[📁 Boomerang/30|30]]**<br><br>*[[📁 Boomerang/Q1#D090|090]]*<br><br>JUN 15 | **[[📁 Boomerang/31|31]]**<br><br>*[[📁 Boomerang/Q1#D091|091]]*<br><br>JUN 16 

🟢 061 - Month Head of cursing  
🟢 075 - Feast of Wheat  
🟣 091 - [[📁 Boomerang/Quarterly|Quarterly]] (182, 273, 364)  
🟣 091 - [[📁 Boomerang/Solstices|Solstices]] (273)

---

---

# Clipboard

```
🟢 000 - 
```
```
🔵 000 - 
```
```
🟣 000 - 
```
```
🟠 000 - 
```
```
🟤 000 - 
```
```
🌺 000 - 
```
```
⚫ 000 - 
```