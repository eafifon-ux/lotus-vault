# Emotional Ladder

10 - Love ==0kJ==
9 - Happiness ==2kJ==
8 - Contentment ==3kJ==
7 - Boredom ==4kJ==

---
6 - Irritation ==10kJ==
5 - Worry ==9kJ==
4 - Anger ==6kJ==
3 - Jealousy ==6kJ==
2 - Insecurity ==5kJ==
1 - Depression ==4kJ==

[📹 YouTube](https://youtu.be/rvyX72oKRns?si=R1plji625kfWyiHk)

# TikTok Text
This is the emotional ladder. Negative emotions are emotions that rob us of our energy and therefore time. We have the least amount of energy at the bottom of the ladder, depression. Feeling anger after depression is a sign that one is moving up the ladder. 

Fear and depression are both at the bottom of the ladder. These emotions mean you have the absolute least amount of energy. Attempting to do anything can feel futile.

A step above depression is insecurity and guilt.

Jealousy and anger are similar. They are in close proximity.

Passion is anger and love mixed

I believe at the top of the negative emotional ladder is irritation, which accumulated becomes stress. This has come to define the modern world because our lives are changing faster than most are capable of adapting.

We reach higher vibrations when we reach boredom and pessimism, next step is contentment and hope then happiness and optimism. 

Finally we are most joyful and our fullest selves when we experience love, freedom and empowerment.

[[📁 Boomerang/Dissertation on emotions|Dissertation on emotions]]
