# + Sepafall

[[📁 Boomerang/Sixsum|☀️ XS]] [[Home|  🏠  ]] [[📁 Boomerang/Oktafall|🍂 OF]]

| [[📁 Boomerang/FR|🟠 W]] | [[📁 Boomerang/FV|🟤 TH]] | [[📁 Boomerang/SS|🌺 F]] | [[📁 Boomerang/SH|⚫ S]] | [[📁 Boomerang/UN|🟢 SN]] | [[📁 Boomerang/DU|🔵 M]] | [[📁 Boomerang/TR|🟣 T]] |
| -- | -- | -- | -- | -- | -- | -- |
| ==orange:**[[📁 Boomerang/1|1]]**<br><br>*[[📁 Boomerang/Q3#D183|183]]*<br><br>SEP 16 ==| **[[📁 Boomerang/2|2]]**<br><br>*[[📁 Boomerang/Q3#D184|184]]*<br><br>SEP 17 | **[[📁 Boomerang/3|3]]**<br><br>*[[📁 Boomerang/Q3#D185|185]]*<br><br>SEP 18 | **[[📁 Boomerang/4|4]]**<br><br>*[[📁 Boomerang/Q3#D186|186]]*<br><br>SEP 19 | **[[📁 Boomerang/5|5]]**<br><br>*[[📁 Boomerang/Q3#D187|187]]*<br><br>SEP 20 | **[[📁 Boomerang/6|6]]**<br><br>*[[📁 Boomerang/Q3#D188|188]]*<br><br>SEP 21 | **[[📁 Boomerang/7|7]]**<br><br>*[[📁 Boomerang/Q3#D189|189]]*<br><br>SEP 22 |
| ==orange:**[[📁 Boomerang/8|8]]**<br><br>*[[📁 Boomerang/Q3#D190|190]]*<br><br>SEP 23 ==| **[[📁 Boomerang/9|9]]**<br><br>*[[📁 Boomerang/Q3#D191|191]]*<br><br>SEP 24 | **[[📁 Boomerang/10|10]]**<br><br>*[[📁 Boomerang/Q3#D192|192]]*<br><br>SEP 25 | **[[📁 Boomerang/11|11]]**<br><br>*[[📁 Boomerang/Q3#D193|193]]*<br><br>SEP 26 | **[[📁 Boomerang/12|12]]**<br><br>*[[📁 Boomerang/Q3#D194|194]]*<br><br>SEP 27 | **[[📁 Boomerang/13|13]]**<br><br>*[[📁 Boomerang/Q3#D195|195]]*<br><br>SEP 28 | **[[📁 Boomerang/14|14]]**<br><br>*[[📁 Boomerang/Q3#D196|196]]*<br><br>SEP 29 |
| ==orange:**[[📁 Boomerang/15|15]]**<br><br>*[[📁 Boomerang/Q3#D197|197]]*<br><br>SEP 30 ==| **[[📁 Boomerang/16|16]]**<br><br>*[[📁 Boomerang/Q3#D198|198]]*<br><br>OCT 1 | **[[📁 Boomerang/17|17]]**<br><br>*[[📁 Boomerang/Q3#D199|199]]*<br><br>OCT 2 | **[[📁 Boomerang/18|18]]**<br><br>*[[📁 Boomerang/Q3#D200|200]]*<br><br>OCT 3 | **[[📁 Boomerang/19|19]]**<br><br>*[[📁 Boomerang/Q3#D201|201]]*<br><br>OCT 4 | **[[📁 Boomerang/20|20]]**<br><br>*[[📁 Boomerang/Q3#D202|202]]*<br><br>OCT 5 | **[[📁 Boomerang/21|21]]**<br><br>*[[📁 Boomerang/Q3#D203|203]]*<br><br>OCT 6 |
| ==orange:**[[📁 Boomerang/22|22]]**<br><br>*[[📁 Boomerang/Q3#D204|204]]*<br><br>OCT 7 ==| **[[📁 Boomerang/23|23]]**<br><br>*[[📁 Boomerang/Q3#D205|205]]*<br><br>OCT 8 | **[[📁 Boomerang/24|24]]**<br><br>*[[📁 Boomerang/Q3#D206|206]]*<br><br>OCT 9 | **[[📁 Boomerang/25|25]]**<br><br>*[[📁 Boomerang/Q3#D207|207]]*<br><br>OCT 10 | **[[📁 Boomerang/26|26]]**<br><br>*[[📁 Boomerang/Q3#D208|208]]*<br><br>OCT 11 | **[[📁 Boomerang/27|27]]**<br><br>*[[📁 Boomerang/Q3#D209|209]]*<br><br>OCT 12 | **[[📁 Boomerang/28|28]]**<br><br>*[[📁 Boomerang/Q3#D210|210]]*<br><br>OCT 13 |
| ==orange:**[[📁 Boomerang/29|29]]**<br><br>*[[📁 Boomerang/Q3#D211|211]]*<br><br>OCT 14 ==| **[[📁 Boomerang/30|30]]**<br><br>*[[📁 Boomerang/Q3#D212|212]]*<br><br>OCT 15 | | | | | |

🟠 183 - Feast of Trumpets
🟤 191 - Day of Atonement
🌺 192 - Day of Atonement
🟢 187 - Meeting
🟠 197 - Tabernacles
🟠 204 - Eighth Day of Sukot

---

---

# Clipboard

```
🟢 000 - 
```
```
🔵 000 - 
```
```
🟣 000 - 
```
```
🟠 000 - 
```
```
🟤 000 - 
```
```
🌺 000 - 
```
```
⚫ 000 - 
```