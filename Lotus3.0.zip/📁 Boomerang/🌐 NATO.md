# 🌐 NATO

[[📁 Boomerang/Events|🗓️ Events]]

- [[📁 Boomerang/One Ahead|One Ahead]] 🇰🇼
- [[📁 Boomerang/Two Ahead|Two Ahead]] 🇮🇱
- [[📁 Boomerang/Three Ahead|Three Ahead]]
- [[📁 Boomerang/Four Ahead|Four Ahead]]
- [[📁 Boomerang/Five Ahead|Five Ahead]]
- [[📁 Boomerang/Six Ahead|Six Ahead]]
- [[📁 Boomerang/Seven Ahead|Seven Ahead]]
- [[📁 Boomerang/Eight Ahead|Eight Ahead]]
- [[📁 Boomerang/Nine Ahead|Nine Ahead]] 🇺🇸 NY
- [[📁 Boomerang/Ten Ahead|Ten Ahead]]
- [[📁 Boomerang/Eleven Ahead|Eleven Ahead]] 🇺🇸 IL 
- [[📁 Boomerang/Twelve Ahead|Twelve Ahead]] 🇺🇸 CA
- [[📁 Boomerang/Thirteen Ahead|Thirteen Ahead]]
- [[📁 Boomerang/Fourteen Ahead|Fourteen Ahead]]
- [[📁 Boomerang/One Behind|One Behind]]
- [[📁 Boomerang/Two Behind|Two Behind]]
- [[📁 Boomerang/Three Behind|Three Behind]]
- [[📁 Boomerang/Four Behind|Four Behind]]
- [[📁 Boomerang/Five Behind|Five Behind]]
- [[📁 Boomerang/Six Behind|Six Behind]]
- [[📁 Boomerang/Seven Behind|Seven Behind]]
- [[📁 Boomerang/Eight Behind|Eight Behind]]
- [[📁 Boomerang/Nine Behind|Nine Behind]]
- [[📁 Boomerang/Ten Behind|Ten Behind]]
- [[📁 Boomerang/Eleven Behind|Eleven Behind]]
- [[📁 Boomerang/Twelve Behind|Twelve Behind]]
- [[📁 Boomerang/Thirteen Behind|Thirteen Behind]]
- [[📁 Boomerang/Fourteen Behind|Fourteen Behind]]
- [[📁 Boomerang/Zero|Zero]]

---

- **Alpha** (A): +1  
- **Bravo** (B): +2
- **Charlie** (C): +3
- **Delta** (D): +4
- **Echo** (E): +5
- **Foxtrot** (F): +6
- **Golf** (G): +7
- **Hotel** (H): +8
- **India** (I): +9
- **Kilo** (K): +10
- **Lima** (L): +11
- **Mike** (M): +12
- **November** (N): −1 hour
- **Oscar** (O): −2
- **Papa** (P): −3
- **Quebec** (Q): −4
- **Romeo** (R): −5
- **Sierra** (S): −6
- **Tango** (T): −7
- **Uniform** (U): −8
- **Victor** (V): −9
- **Whiskey** (W): −10
- **X-ray** (X): −11
- **Yankee** (Y): −12
- **Zulu** (Z): 0 hours

---