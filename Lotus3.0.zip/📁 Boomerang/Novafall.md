# Novafall

[[📁 Boomerang/Oktafall|🍂 OF]] [[Home|  🏠  ]] [[📁 Boomerang/Dekawint|❄️ XW]]

| [[📁 Boomerang/FR|🟠 W]] | [[📁 Boomerang/FV|🟤 TH]] | [[📁 Boomerang/SS|🌺 F]] | [[📁 Boomerang/SH|⚫ S]] | [[📁 Boomerang/UN|🟢 SN]] | [[📁 Boomerang/DU|🔵 M]] | [[📁 Boomerang/TR|🟣 T]] |
| -- | -- | -- | -- | -- | -- | -- |
| | | | | ==green:**[[📁 Boomerang/1|1]]**<br><br>*[[📁 Boomerang/Q3#D243|243]]*<br><br>NOV 15 ==| **[[📁 Boomerang/2|2]]**<br><br>*[[📁 Boomerang/Q3#D244|244]]*<br><br>NOV 16 | **[[📁 Boomerang/3|3]]**<br><br>*[[📁 Boomerang/Q3#D245|245]]*<br><br>NOV 17 |
| **[[📁 Boomerang/4|4]]**<br><br>*[[📁 Boomerang/Q3#D246|246]]*<br><br>NOV 18 | **[[📁 Boomerang/5|5]]**<br><br>*[[📁 Boomerang/Q3#D247|247]]*<br><br>NOV 19 | **[[📁 Boomerang/6|6]]**<br><br>*[[📁 Boomerang/Q3#D248|248]]*<br><br>NOV 20 | **[[📁 Boomerang/7|7]]**<br><br>*[[📁 Boomerang/Q3#D249|249]]*<br><br>NOV 21 | ==green:**[[📁 Boomerang/8|8]]**<br><br>*[[📁 Boomerang/Q3#D250|250]]*<br><br>NOV 22 ==| **[[📁 Boomerang/9|9]]**<br><br>*[[📁 Boomerang/Q3#D251|251]]*<br><br>NOV 23 | **[[📁 Boomerang/10|10]]**<br><br>*[[📁 Boomerang/Q3#D252|252]]*<br><br>NOV 24 |
| **[[📁 Boomerang/11|11]]**<br><br>*[[📁 Boomerang/Q3#D253|253]]*<br><br>NOV 25 | **[[📁 Boomerang/12|12]]**<br><br>*[[📁 Boomerang/Q3#D254|254]]*<br><br>NOV 26 | **[[📁 Boomerang/13|13]]**<br><br>*[[📁 Boomerang/Q3#D255|255]]*<br><br>NOV 27 | **[[📁 Boomerang/14|14]]**<br><br>*[[📁 Boomerang/Q3#D256|256]]*<br><br>NOV 28 | ==green:**[[📁 Boomerang/15|15]]**<br><br>*[[📁 Boomerang/Q3#D257|257]]*<br><br>NOV 29 ==| **[[📁 Boomerang/16|16]]**<br><br>*[[📁 Boomerang/Q3#D258|258]]*<br><br>NOV 30 | **[[📁 Boomerang/17|17]]**<br><br>*[[📁 Boomerang/Q3#D259|259]]*<br><br>DEC 1 |
| **[[📁 Boomerang/18|18]]**<br><br>*[[📁 Boomerang/Q3#D260|260]]*<br><br>DEC 2 | **[[📁 Boomerang/19|19]]**<br><br>*[[📁 Boomerang/Q3#D261|261]]*<br><br>DEC 3 | **[[📁 Boomerang/20|20]]**<br><br>*[[📁 Boomerang/Q3#D262|262]]*<br><br>DEC 4 | **[[📁 Boomerang/21|21]]**<br><br>*[[📁 Boomerang/Q3#D263|263]]*<br><br>DEC 5 | ==green:**[[📁 Boomerang/22|22]]**<br><br>*[[📁 Boomerang/Q3#D264|264]]*<br><br>DEC 6 ==| **[[📁 Boomerang/23|23]]**<br><br>*[[📁 Boomerang/Q3#D265|265]]*<br><br>DEC 7 | **[[📁 Boomerang/24|24]]**<br><br>*[[📁 Boomerang/Q3#D266|266]]*<br><br>DEC 8 |
| **[[📁 Boomerang/25|25]]**<br><br>*[[📁 Boomerang/Q3#D267|267]]*<br><br>DEC 9 | **[[📁 Boomerang/26|26]]**<br><br>*[[📁 Boomerang/Q3#D268|268]]*<br><br>DEC 10 | **[[📁 Boomerang/27|27]]**<br><br>*[[📁 Boomerang/Q3#D269|269]]*<br><br>DEC 11 | **[[📁 Boomerang/28|28]]**<br><br>*[[📁 Boomerang/Q3#D270|270]]*<br><br>DEC 12 | ==green:**[[📁 Boomerang/29|29]]**<br><br>*[[📁 Boomerang/Q3#D271|271]]*<br><br>DEC 13 ==| **[[📁 Boomerang/30|30]]**<br><br>*[[📁 Boomerang/Q3#D272|272]]*<br><br>DEC 14 | **[[📁 Boomerang/31|31]]**<br><br>*[[📁 Boomerang/Q3#D273|273]]*<br><br>DEC 15

🟢 243 - Month Head
🟤 247 - Meeting
🟣 273 - [[📁 Boomerang/Quarterly|Quarterly]] (091, 182, 364)
🟣 273 - [[📁 Boomerang/Solstices|Solstices]] (091)

---

---

# Clipboard

```
🟢 000 - 
```
```
🔵 000 - 
```
```
🟣 000 - 
```
```
🟠 000 - 
```
```
🟤 000 - 
```
```
🌺 000 - 
```
```
⚫ 000 - 
```