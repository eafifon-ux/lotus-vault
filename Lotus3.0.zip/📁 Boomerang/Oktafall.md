# Oktafall

[[📁 Boomerang/Sepafall|🍂 SF]] [[Home|  🏠  ]] [[📁 Boomerang/Novafall|🍂 NF]]

| [[📁 Boomerang/FR|🟠 W]] | [[📁 Boomerang/FV|🟤 TH]] | [[📁 Boomerang/SS|🌺 F]] | [[📁 Boomerang/SH|⚫ S]] | [[📁 Boomerang/UN|🟢 SN]] | [[📁 Boomerang/DU|🔵 M]] | [[📁 Boomerang/TR|🟣 T]] |
| -- | -- | -- | -- | -- | -- | -- |
| | | ==pink:**[[📁 Boomerang/1|1]]**<br><br>*[[📁 Boomerang/Q3#D213|213]]*<br><br>OCT 16 ==| **[[📁 Boomerang/2|2]]**<br><br>*[[📁 Boomerang/Q3#D214|214]]*<br><br>OCT 17 | **[[📁 Boomerang/3|3]]**<br><br>*[[📁 Boomerang/Q3#D215|215]]*<br><br>OCT 18 | **[[📁 Boomerang/4|4]]**<br><br>*[[📁 Boomerang/Q3#D216|216]]*<br><br>OCT 19 | **[[📁 Boomerang/5|5]]**<br><br>*[[📁 Boomerang/Q3#D217|217]]*<br><br>OCT 20 |
| **[[📁 Boomerang/6|6]]**<br><br>*[[📁 Boomerang/Q3#D218|218]]*<br><br>OCT 21 | **[[📁 Boomerang/7|7]]**<br><br>*[[📁 Boomerang/Q3#D219|219]]*<br><br>OCT 22 | ==pink:**[[📁 Boomerang/8|8]]**<br><br>*[[📁 Boomerang/Q3#D220|220]]*<br><br>OCT 23 ==| **[[📁 Boomerang/9|9]]**<br><br>*[[📁 Boomerang/Q3#D221|221]]*<br><br>OCT 24 | **[[📁 Boomerang/10|10]]**<br><br>*[[📁 Boomerang/Q3#D222|222]]*<br><br>OCT 25 | **[[📁 Boomerang/11|11]]**<br><br>*[[📁 Boomerang/Q3#D223|223]]*<br><br>OCT 26 | **[[📁 Boomerang/12|12]]**<br><br>*[[📁 Boomerang/Q3#D224|224]]*<br><br>OCT 27 |
| **[[📁 Boomerang/13|13]]**<br><br>*[[📁 Boomerang/Q3#D225|225]]*<br><br>OCT 28 | **[[📁 Boomerang/14|14]]**<br><br>*[[📁 Boomerang/Q3#D226|226]]*<br><br>OCT 29 | ==pink:**[[📁 Boomerang/15|15]]**<br><br>*[[📁 Boomerang/Q3#D227|227]]*<br><br>OCT 30 ==| **[[📁 Boomerang/16|16]]**<br><br>*[[📁 Boomerang/Q3#D228|228]]*<br><br>OCT 31 | **[[📁 Boomerang/17|17]]**<br><br>*[[📁 Boomerang/Q3#D229|229]]*<br><br>NOV 1 | **[[📁 Boomerang/18|18]]**<br><br>*[[📁 Boomerang/Q3#D230|230]]*<br><br>NOV 2 | **[[📁 Boomerang/19|19]]**<br><br>*[[📁 Boomerang/Q3#D231|231]]*<br><br>NOV 3 |
| **[[📁 Boomerang/20|20]]**<br><br>*[[📁 Boomerang/Q3#D232|232]]*<br><br>NOV 4 | **[[📁 Boomerang/21|21]]**<br><br>*[[📁 Boomerang/Q3#D233|233]]*<br><br>NOV 5 | ==pink:**[[📁 Boomerang/22|22]]**<br><br>*[[📁 Boomerang/Q3#D234|234]]*<br><br>NOV 6 ==| **[[📁 Boomerang/23|23]]**<br><br>*[[📁 Boomerang/Q3#D235|235]]*<br><br>NOV 7 | **[[📁 Boomerang/24|24]]**<br><br>*[[📁 Boomerang/Q3#D236|236]]*<br><br>NOV 8 | **[[📁 Boomerang/25|25]]**<br><br>*[[📁 Boomerang/Q3#D237|237]]*<br><br>NOV 9 | **[[📁 Boomerang/26|26]]**<br><br>*[[📁 Boomerang/Q3#D238|238]]*<br><br>NOV 10 |
| **[[📁 Boomerang/27|27]]**<br><br>*[[📁 Boomerang/Q3#D239|239]]*<br><br>NOV 11 | **[[📁 Boomerang/28|28]]**<br><br>*[[📁 Boomerang/Q3#D240|240]]*<br><br>NOV 12 | ==pink:**[[📁 Boomerang/29|29]]**<br><br>*[[📁 Boomerang/Q3#D241|241]]*<br><br>NOV 13 ==| **[[📁 Boomerang/30|30]]**<br><br>*[[📁 Boomerang/Q3#D242|242]]*<br><br>NOV 14

🌺 213 - Month Head
🟣 217 - Meeting

---

---

# Clipboard

```
🟢 000 - 
```
```
🔵 000 - 
```
```
🟣 000 - 
```
```
🟠 000 - 
```
```
🟤 000 - 
```
```
🌺 000 - 
```
```
⚫ 000 - 
```