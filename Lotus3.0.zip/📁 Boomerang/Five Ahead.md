# Five Ahead

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Four Ahead|4️⃣🅰️]] | [[📁 Boomerang/Six Ahead|6️⃣🅰️]] |
| -- | -- |

| Current Location | Juliet |
|------------------|--------|
| 🟡 1  | 6 🟡  |
| 🟡 2  | 7 🟡  |
| 🟡 3  | 8 🟡  |
| 🟡 4  | 9 🟡  |
| 🟡 5  | 10 🟡 |
| 🟡 6  | 11 🟡 |
| 🟡 7  | 12 🟡 |
| 🟡 8  | 13 🟡 |
| 🟡 9  | 14 🟡 |
| 🟡 10 | 15 🟡 |
| 🟡 11 | 16 🟡 |
| 12    | 💤 17 |
| 13    | 💤 18 |
| 14    | 💤 19 |
| 15    | 💤 20 |
| 16    | 💤 21 |
| 17 💤 | 💤 22 |
| 18 💤 | 💤 23 |
| 19 💤 | 💤 24 |
| 20 💤 | 1  |
| 21 💤 | 2  |
| 22 💤 | 3  |
| 23 💤 | 4  |
| 24 💤 | 5  |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 🟡 7  | 12 🟡  |
| 🟡 8  | 13 🟡  |
| 🟡 9  | 14 🟡  |
| 🟡 10  | 15 🟡  |
| 🟡 11  | 16 🟡  |
| 🟡 12  | 17 🟡  |
| 🟡 13  | 18 🟡  |
| 🟡 14  | 19 🟡  |
| 🟡 15  | 20 🟡  |
| 🟡 16  | 21 🟡  |
| 🟡 17  | 22 🟡  |
| 18    | 💤 23 |
| 19    | 💤 24 |
| 20    | 💤 1  |
| 21    | 💤 2  |
| 22    | 💤 3  |
| 23 💤 | 💤 4  |
| 24 💤 | 💤 5  |
| 1 💤  | 💤 6  |
| 2 💤  | 7  |
| 3 💤  | 8  |
| 4 💤  | 9  |
| 5 💤  | 10 |
| 6 💤  | 11 |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)