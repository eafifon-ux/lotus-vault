# Universal Laws

Harnek Singh's enumeration of universal laws

1. Law of Thermodynamics
2. Law of Correspondence
3. Law of Attraction
4. Law of Cause and Effect
5. Law of Detachment
6. Law of Vibration
7. Law of Polarity
8. Law of Scarcity
9. Law of Perspective

---

1. Everything tends towards decay
2. As above so below. Understanding impermanence leads to truth
3. Like frequencies attract each other
4. Life is like a boomerang
5. When you need something you repel it, when you are detached from it you are magnetic
6. Everything vibrates: keep your thoughts on what you want and not on what you don't want
7. A bad experience is an equal opportunity
8. Familiarity breeds disrespect
9. Your perspective is either your prison or your passport

Murphy's law is the law of vibration so I didn't include it. The Chinese were aware of it. They said "speak about a tiger and it will appear". The order is influenced by The Four Thoughts. Robert Kiosaki's sister is a nun. All self improvement memes and reels are just eastern thought rebranded. A lot of science is too.