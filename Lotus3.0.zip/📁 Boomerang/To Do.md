# To Do

| [[📁 Boomerang/Shopping|Shopping]] | [[📁 Boomerang/Notes|Notes]] |
| -- | -- |

### + In Progress 
- [ ] water bill

### Waiting
- [ ] Boat

### Back Burner
- [ ] Hawaii 
