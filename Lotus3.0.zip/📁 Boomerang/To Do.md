# To Do

| [[📁 Boomerang/Shopping|Shopping]] | [[📁 Boomerang/Campaign|Campaign]] |
| -- | -- |

### + In Progress 
- [ ] water bill

### Waiting
- [ ] Boat

### Back Burner
- [ ] Hawaii 

[[📁 Boomerang/Notes|Notes]]