# Events

---

| [Logic Board](https://eafifon-ux.github.io/Logic-Board/) | [[📁 Boomerang/Septet|🕎 Septet]] | [[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]|  [[📁 Boomerang/🌐 NATO|🌐 NATO]] |
| -- | -- | -- | -- |

---

188 - Shoshanah release
295 - GPCversionVII release
303 - Lotus release


