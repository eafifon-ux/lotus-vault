# Monthly

- [ ] Clean phone
- [ ] Backup Files
- [ ] Sharpen knife
- [ ] Tire pressure
- [ ] Check oil
- [ ] Check cams 