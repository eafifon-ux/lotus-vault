# Timeline

| [Human History](https://fixedcal.blogspot.com/p/timeline.html?m=1) | [Today](https://www.gpc364.com/p/today.html?m=1) |
| -- | -- | 

- 🌺 5946.213 born
- 🟣 6022.315 Lotus 1.9

# Gregorian

- 🌺 1949-10-21 born
- 🟣 2026-01-27 Lotus 1.9

# Clipboard

```
🟢 
```
```
🔵 
```
```
🟣 
```
```
🟠 
```
```
🟤 
```
```
🌺 
```
```
⚫ 
```

# Goals
- Nirvana