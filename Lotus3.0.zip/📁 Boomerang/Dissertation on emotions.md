# Dissertation on emotions

A dissertation on emotions by Harnek Singh 

חנוך עפיפון

Sup guys. I want to talk about the emotional ladder 🪜. This is the most powerful tool that can heal the entire word. 

10. Love
11. Joy 
12. Contentment
13. Boredom
14. Irritation
15. Worry 
16. Anger 
17. Jealousy
18. Insecurity 
19. Depression

The stock market and money and all of human society works off this ladder. A lot of failure, dysfunction and turmoil in the world stems simply from not understanding the ladder. Billionaires are people that just surround themselves with people that are smarter than themselves and also have full control of their emotions. So let's break down what are emotions? 

All negative emotions are just wastes of energy. Your body consumes it's resources fast as a way of signaling something is wrong. 

Let's start with fear and depression¹. Both are the first step or bottom of the ladder. Fear keeps us alive and protects us. A healthy amount exists. When we outsource this emotion to other people or organizations such as the media then it becomes toxic. Depression is living in the past.

The cousin of fear is insecurity². It's a type of fear and a small amount can lead us to take better care of ourselves. Too much can lead us to a destructive lifestyle. 

Next is jealousy³ and anger⁴. They are cousins. Jealousy just signals that we are not where we need to be in life. Anger is poor planning. Have you met someone that is constantly displaying fits of rage? Have you seen their time management system? Of course not. They don't have one! You are not angry when you expect it to rain and it does. But unexpected rain often is the source of anger. It's just a sign of poor planning. 

The next two are just in the middle and there seemingly exists no relation. Worry⁵ and irritation⁶. Live in the past depression, live in the future worry, joy can only be experienced in the present. 

Irritation wastes more energy than any other emotion. But unlike depression or fear, irritation is experienced in short bursts. It is our greatest chemical motivator. It's what fixes a leaky roof or causes us to separate ourselves from someone who is loud, rude and obnoxious. Irritation is a great emotion but it is a negative emotion and like all evil and dysfunction it consumes the greatest amount of energy. Did you know that's all evil is? Religions may try to provide morality but the fact is things that are right are efficient and things that are considered immoral such as theft, lying, murder or adultery are just immense wastes of time, money and energy. Time, money and energy are our three synonyms of efficiency and ultimately justice.

Next is boredom⁷ and contentment⁸. Boredom helps us to fulfill ourselves as people. Why do we get bored? My generation are millennials. We have experienced more occupations than any other generation before us. It might be because of boredom but it might also be sudden and dramatic shifts in technology that has forced us to constantly learn and adapt. Anyways that's actually what we should be doing. If not then why does this emotion exist? 

Contentment is when all your needs are met. Your health, wealth and relationships are stable. Enough of that and joy is inevitable. Joy⁹ uses the least amount of energy. A man that is happy is the most effective in any occupation just as a cow that is happy produces the most milk. Lastly is love. Love¹⁰ is the only emotion that uses zero energy. At the top of the emotional ladder is something we all strive for. Really there has to be such a wonderful balance for love to thrive and just merely exist. 

By stepping outside ourself and asking ourselves ourself "why do I feel this way"? we can actually make beautiful and constructive decisions that will have a lasting and positive impact. That is all.