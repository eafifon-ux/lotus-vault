# 🪷 Welcome to Lotus 1.1  
**Your Personal Knowledge Base Powered by the Global Perennial Calendar**

[🗓️ Go to Today → Current Day in GPC](https://www.gpc364.com/p/today.html?m=1)

Capture thoughts, tasks, and time—right here, aligned with the ancient 364-day rhythm.

## Index

- [[📁 Boomerang/Manual#Quick Manual|Quick Manual]]
- [[📁 Boomerang/Manual#Checkbox Headings ✨ NEW!|Checkboxes]]
- [[📁 Boomerang/Manual#Dates & The Global Perennial Calendar (GPC)|Dates]]
- [[📁 Boomerang/Manual#Tables & Calculators|Tables & Calculators]]
- [[📁 Boomerang/Manual#Lists|Lists]]
- [[📁 Boomerang/Manual#Wikilinks & External Links|Wikilinks]]
- [[📁 Boomerang/Manual#Deep Links — Open Apps Directly from Your Notes 🚀|Deep Links]]
- [[📁 Boomerang/Manual#Header Links (Anchors)|Header Links]]
- [[📁 Boomerang/Manual#Final Thoughts|Final Thoughts]]


# + 1.1 Updates
✅ Folder bug resolved
✅ Zip created 

---

     



















**Quick Starts**  
- [[Capture]] — Daily / uncategorized capture  
- [[Notes]] — Organize information
- [[Events]] — Keep Track of everything

***

# Quick Manual

## + Intro

> Headings are collapsible! Tap any heading to toggle sections (try it now using the toolbar).

Switch modes easily:  
- Click the **pencil ✏️** (top right) to edit.  
- The **eye 👁️** means you're in view/read mode.

Explore the toolbar for powerful tools—like quick clipboards:

```
Hello world
```

Highlight text → tap the clipboard icon to save snippets for reuse.

## Checkbox Headings ✨ NEW!

Create interactive headings that combine checkboxes with collapsible content:

```
# + [ ] Project Planning
# + [x] Completed Tasks
# - [ ] Pending Items
# - [x] Archived Items
```

**How it works:**
- Click the **checkbox (☐)** to toggle between checked/unchecked
- Click the **heading text** to collapse/expand content
- `+` = expanded by default
- `-` = collapsed by default
- `[ ]` = unchecked
- `[x]` = checked

## Dates & The Global Perennial Calendar (GPC)

The current GPC date always appears at the top. Our date generator is precise and reliable for over a million years.

Today's display includes:  
- **Day of Year**  
- **Day of Season**  
- **Day of Month**  
- **Heptad** (our 7-day week cycle, labeled with playing-card suits)  
- **Civil (Gregorian) Date**

Example:  
🟠 302  
🟠 Q4 29 
🟠 10.29  
♠️ 4 
2026-01-15

> Pro tip: Tap **Heptad** at the top to include it automatically in date stamps from the toolbar.

With Heptad enabled:  
🟠 302 ♠️ 4  
🟠 Q4 29 ♠️ 4  
🟠 10.29 ♠️ 4  
♠️ 4
2026-01-15 ♠️ 4

Heptads represent our fixed weekly structure—52 perfect weeks per year, inspired by ancient perennial systems.

## Tables & Calculators

Tables support simple built-in calculations with +, -, *.

Example:

|    | Bananas 🍌 |
|----|-----------|
| Marry   | 5         |
| Tom     | 6         |
| Kumar   | 7         |
| Count  |   |
| **Remaining** | **100 - @Σ** |
|Blank::**Quests**|@Count|
| **Σ** | **+**     |

- **==green:@Σ==** references the total from the Σ row (Marry + Tom + Kumar = 18).  
- ==blue:Remaining== becomes **100 - 18 = 82**.  
- Use **==green:@==** to cross-reference other calculator cells/tables.
- Only second column performs arithmetic
- ==pink:@Count== simply adds all blank rows
- Use double colon to rename rows. Like this: Blank::**Quests**

## Lists

Bullets, numbers, and checkboxes—all fully supported.

- Item 1  
- Item 2  
- Item 3  

1. Marry  
2. Tom  
3. Kumar  

- [ ] Apples 🍎  
- [ ] Oranges 🍊  
- [ ] Bananas 🍌  

> Checkboxes are interactive: drag to reorder, click to toggle. Great for tasks!

## + Wikilinks & External Links

Wikilinks are the heart of this system—turn any word into a page link.

Toolbar → far-right icon (🗒️ page symbol) → create [[Capture]] instantly.

Toolbar → far-right icon (📁 folder page symbol) → a folder based wikilink.

Rename for clarity using a pipe |:  
[[Capture|Daily Journal]]

For external sites: highlight text → tap the **🔗** link icon.

Example: [[Capture]] takes you straight to your current daily note.

## Deep Links — Open Apps Directly from Your Notes 🚀

Lotus is the first and only Markdown editor designed to work seamlessly with deep links.

A deep link is a special link that opens an app or triggers an action directly on your device. Instead of switching apps and searching manually, your notes can instantly launch tools, conversations, media, or services.

Because Lotus uses simple Markdown links, deep links work exactly like normal links—just tap them.

Examples

[📨 Email](mailto:user@gmail.com)
[📞 Text](sms:+10001234567)
[💬 Messenger](https://m.me/facebook)
[🍏 WhatsApp](https://wa.me/10001234567)
[🚕 Uber](uber://?action=setPickup)
[🛒 Amazon Cart](amazon://cart)
[🎧 Spotify](spotify:)
[▶️ YouTube](https://youtube.com)
[🗺️ Maps](https://maps.google.com)

When tapped, these links open the corresponding app if it is installed. If the app isn’t installed, many links automatically open the web version instead.

**Why this matters**

Most note apps simply store information.

Lotus allows your notes to trigger actions.

Your pages can become:

- **A communication dashboard** (email, SMS, chat apps)
- **A media launcher** (music, video, podcasts)
- **A shopping hub** (open carts and stores)
- **A travel toolkit** (maps, rides, directions)
- **A personal control panel** for your device

Example: A Personal Action Panel

### My Daily Tools

[📞 Call Mom](tel:+10001234567)
[💬 WhatsApp](https://wa.me/10001234567)
[🎧 Music](spotify:)
[▶️ YouTube](https://youtube.com)
[🗺️ Maps](https://maps.google.com)
[🚕 Ride](uber://?action=setPickup)

With just a few links, a Lotus page becomes a launcher for the apps you use every day.

The Philosophy

Lotus combines three powerful ideas:

• Markdown simplicity
• Wikilink knowledge organization
• Deep link app control

Together they create something new: a living knowledge base that interacts with your entire device.

Your notes are no longer passive documents.

They become gateways to the tools, people, and information you rely on every day. 🪷

## + Header Links (Anchors)
Jump directly to sections within the same page or other notes using # anchors.
**Format**: ==gray:[[Page#Heading|Display Text] ]== (remove space between ] ])
**Examples**:
- Same page: ==gray:[[#Intro|Quick Manual]]== → Jumps to Intro section here
- Other page: ==gray:[[📁 Boomerang/Manual#Intro|Manual] ]== → Jumps to Manual's Intro [[📁 Boomerang/Manual#Intro|Manual]]
- Folder path: ==gray:[[📁 Projects/Notes#Dates|GPC Dates] ]== → Precise section navigation
**Tips**:
- Use full heading text after # (including emojis/symbols like #🪷 Welcome)
- Pipe | customizes the clickable display text
- Perfect for Quick Starts lists or cross-references
- Works across your entire vault for seamless navigation

## + Final Thoughts

I hope this app becomes a trusted companion on your journey.  

For over 15 years, I've studied the Dead Sea Scrolls, ancient timekeeping systems, and modern productivity masters like Brian Tracy. This tool is the result—a digital home for perennial wisdom in a chaotic world.

A gentle reminder pops up every Wednesday: **Backup your notes** (safety first!).

Enjoy exploring.  

> May you have a calm mind and useful thoughts.  
> May you accomplish great things with little energy. 