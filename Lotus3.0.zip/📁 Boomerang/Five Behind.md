# Five Behind

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Four Behind|4️⃣🅱️]] | [[📁 Boomerang/Six Behind|6️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|------------------|--------|
| 1       | 💤 20 |
| 2       | 💤 21 |
| 3       | 💤 22 |
| 4       | 💤 23 |
| 5       | 💤 24 |
| 🟡 6    | 1 🟡  |
| 🟡 7    | 2 🟡  |
| 🟡 8    | 3 🟡  |
| 🟡 9    | 4 🟡  |
| 🟡 10   | 5 🟡  |
| 🟡 11   | 6 🟡  |
| 🟡 12   | 7 🟡  |
| 🟡 13   | 8 🟡  |
| 🟡 14   | 9 🟡  |
| 🟡 15   | 10 🟡 |
| 🟡 16   | 11 🟡 |
| 17 💤   | 12 |
| 18 💤   | 13 |
| 19 💤   | 14 |
| 20 💤   | 15 |
| 21 💤   | 16 |
| 22 💤   | 💤 17 |
| 23 💤   | 💤 18 |
| 24 💤   | 💤 19 |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 7       | 💤 1  |
| 8       | 💤 2  |
| 9       | 💤 3  |
| 10      | 💤 4  |
| 11      | 💤 5  |
| 🟡 12   | 7 🟡  |
| 🟡 13   | 8 🟡  |
| 🟡 14   | 9 🟡  |
| 🟡 15   | 10 🟡 |
| 🟡 16   | 11 🟡 |
| 🟡 17   | 12 🟡 |
| 🟡 18   | 13 🟡 |
| 🟡 19   | 14 🟡 |
| 🟡 20   | 15 🟡 |
| 🟡 21   | 16 🟡 |
| 🟡 22   | 17 🟡 |
| 23 💤   | 18    |
| 24 💤   | 19    |
| 1 💤    | 20    |
| 2 💤    | 21    |
| 3 💤    | 22    |
| 4 💤    | 💤 23 |
| 5 💤    | 💤 24 |
| 6 💤    | 💤 1  |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)