# + Q1Notes
| [[📁 Boomerang/Q4Notes|Q4Notes]]   | [[📁 Boomerang/Q2Notes|Q2Notes]]   |
|----|----|

## + D001
[[📁 Boomerang/Q1#D001|Day 001]]  
> ~🟠 2026-03-18~  

## + D002
[[📁 Boomerang/Q1#D002|Day 002]]  
> ~🟤 2026-03-19~  

## + D003
[[📁 Boomerang/Q1#D003|Day 003]]  
> ~🌺 2026-03-20~  

## + D004
[[📁 Boomerang/Q1#D004|Day 004]]  
> ~⚫ 2026-03-21~  

## + D005
[[📁 Boomerang/Q1#D005|Day 005]]  
> ~🟢 2026-03-22~  

## + D006
[[📁 Boomerang/Q1#D006|Day 006]]  
> ~🔵 2026-03-23~  

## + D007
[[📁 Boomerang/Q1#D007|Day 007]]  
> ~🟣 2026-03-24~  

## + D008
[[📁 Boomerang/Q1#D008|Day 008]]  
> ~🟠 2026-03-25~  

## + D009
[[📁 Boomerang/Q1#D009|Day 009]]  
> ~🟤 2026-03-26~  

## + D010
[[📁 Boomerang/Q1#D010|Day 010]]  
> ~🌺 2026-03-27~  

## + D011
[[📁 Boomerang/Q1#D011|Day 011]]  
> ~⚫ 2026-03-28~  

## + D012
[[📁 Boomerang/Q1#D012|Day 012]]  
> ~🟢 2026-03-29~  

## + D013
[[📁 Boomerang/Q1#D013|Day 013]]  
> ~🔵 2026-03-30~  

## + D014
[[📁 Boomerang/Q1#D014|Day 014]]  
> ~🟣 2026-03-31~  

## + D015
[[📁 Boomerang/Q1#D015|Day 015]]  
> ~🟠 2026-04-01~  

## + D016
[[📁 Boomerang/Q1#D016|Day 016]]  
> ~🟤 2026-04-02~  

## + D017
[[📁 Boomerang/Q1#D017|Day 017]]  
> ~🌺 2026-04-03~  

## + D018
[[📁 Boomerang/Q1#D018|Day 018]]  
> ~⚫ 2026-04-04~  

## + D019
[[📁 Boomerang/Q1#D019|Day 019]]  
> ~🟢 2026-04-05~  

## + D020
[[📁 Boomerang/Q1#D020|Day 020]]  
> ~🔵 2026-04-06~  

## + D021
[[📁 Boomerang/Q1#D021|Day 021]]  
> ~🟣 2026-04-07~  

## + D022
[[📁 Boomerang/Q1#D022|Day 022]]  
> ~🟠 2026-04-08~  

## + D023
[[📁 Boomerang/Q1#D023|Day 023]]  
> ~🟤 2026-04-09~  

## + D024
[[📁 Boomerang/Q1#D024|Day 024]]  
> ~🌺 2026-04-10~  

## + D025
[[📁 Boomerang/Q1#D025|Day 025]]  
> ~⚫ 2026-04-11~  

## + D026
[[📁 Boomerang/Q1#D026|Day 026]]  
> ~🟢 2026-04-12~  

## + D027
[[📁 Boomerang/Q1#D027|Day 027]]  
> ~🔵 2026-04-13~  

## + D028
[[📁 Boomerang/Q1#D028|Day 028]]  
> ~🟣 2026-04-14~  

## + D029
[[📁 Boomerang/Q1#D029|Day 029]]  
> ~🟠 2026-04-15~  

## + D030
[[📁 Boomerang/Q1#D030|Day 030]]  
> ~🟤 2026-04-16~  

## + D031
[[📁 Boomerang/Q1#D031|Day 031]]  
> ~🌺 2026-04-17~  

## + D032
[[📁 Boomerang/Q1#D032|Day 032]]  
> ~⚫ 2026-04-18~  

## + D033
[[📁 Boomerang/Q1#D033|Day 033]]  
> ~🟢 2026-04-19~  

## + D034
[[📁 Boomerang/Q1#D034|Day 034]]  
> ~🔵 2026-04-20~  

## + D035
[[📁 Boomerang/Q1#D035|Day 035]]  
> ~🟣 2026-04-21~  

## + D036
[[📁 Boomerang/Q1#D036|Day 036]]  
> ~🟠 2026-04-22~  

## + D037
[[📁 Boomerang/Q1#D037|Day 037]]  
> ~🟤 2026-04-23~  

## + D038
[[📁 Boomerang/Q1#D038|Day 038]]  
> ~🌺 2026-04-24~  

## + D039
[[📁 Boomerang/Q1#D039|Day 039]]  
> ~⚫ 2026-04-25~  

## + D040
[[📁 Boomerang/Q1#D040|Day 040]]  
> ~🟢 2026-04-26~  

## + D041
[[📁 Boomerang/Q1#D041|Day 041]]  
> ~🔵 2026-04-27~  

## + D042
[[📁 Boomerang/Q1#D042|Day 042]]  
> ~🟣 2026-04-28~  

## + D043
[[📁 Boomerang/Q1#D043|Day 043]]  
> ~🟠 2026-04-29~  

## + D044
[[📁 Boomerang/Q1#D044|Day 044]]  
> ~🟤 2026-04-30~  

## + D045
[[📁 Boomerang/Q1#D045|Day 045]]  
> ~🌺 2026-05-01~  

## + D046
[[📁 Boomerang/Q1#D046|Day 046]]  
> ~⚫ 2026-05-02~  

## + D047
[[📁 Boomerang/Q1#D047|Day 047]]  
> ~🟢 2026-05-03~  

## + D048
[[📁 Boomerang/Q1#D048|Day 048]]  
> ~🔵 2026-05-04~  

## + D049
[[📁 Boomerang/Q1#D049|Day 049]]  
> ~🟣 2026-05-05~  

## + D050
[[📁 Boomerang/Q1#D050|Day 050]]  
> ~🟠 2026-05-06~  

## + D051
[[📁 Boomerang/Q1#D051|Day 051]]  
> ~🟤 2026-05-07~  

## + D052
[[📁 Boomerang/Q1#D052|Day 052]]  
> ~🌺 2026-05-08~  

## + D053
[[📁 Boomerang/Q1#D053|Day 053]]  
> ~⚫ 2026-05-09~  

## + D054
[[📁 Boomerang/Q1#D054|Day 054]]  
> ~🟢 2026-05-10~  

## + D055
[[📁 Boomerang/Q1#D055|Day 055]]  
> ~🔵 2026-05-11~  

## + D056
[[📁 Boomerang/Q1#D056|Day 056]]  
> ~🟣 2026-05-12~  

## + D057
[[📁 Boomerang/Q1#D057|Day 057]]  
> ~🟠 2026-05-13~  

## + D058
[[📁 Boomerang/Q1#D058|Day 058]]  
> ~🟤 2026-05-14~  

## + D059
[[📁 Boomerang/Q1#D059|Day 059]]  
> ~🌺 2026-05-15~  

## + D060
[[📁 Boomerang/Q1#D060|Day 060]]  
> ~⚫ 2026-05-16~  

## + D061
[[📁 Boomerang/Q1#D061|Day 061]]  
> ~🟢 2026-05-17~  

## + D062
[[📁 Boomerang/Q1#D062|Day 062]]  
> ~🔵 2026-05-18~  

## + D063
[[📁 Boomerang/Q1#D063|Day 063]]  
> ~🟣 2026-05-19~  

## + D064
[[📁 Boomerang/Q1#D064|Day 064]]  
> ~🟠 2026-05-20~  

## + D065
[[📁 Boomerang/Q1#D065|Day 065]]  
> ~🟤 2026-05-21~  

## + D066
[[📁 Boomerang/Q1#D066|Day 066]]  
> ~🌺 2026-05-22~  

## + D067
[[📁 Boomerang/Q1#D067|Day 067]]  
> ~⚫ 2026-05-23~  

## + D068
[[📁 Boomerang/Q1#D068|Day 068]]  
> ~🟢 2026-05-24~  

## + D069
[[📁 Boomerang/Q1#D069|Day 069]]  
> ~🔵 2026-05-25~  

## + D070
[[📁 Boomerang/Q1#D070|Day 070]]  
> ~🟣 2026-05-26~  

## + D071
[[📁 Boomerang/Q1#D071|Day 071]]  
> ~🟠 2026-05-27~  

## + D072
[[📁 Boomerang/Q1#D072|Day 072]]  
> ~🟤 2026-05-28~  

## + D073
[[📁 Boomerang/Q1#D073|Day 073]]  
> ~🌺 2026-05-29~  

## + D074
[[📁 Boomerang/Q1#D074|Day 074]]  
> ~⚫ 2026-05-30~  

## + D075
[[📁 Boomerang/Q1#D075|Day 075]]  
> ~🟢 2026-05-31~  

## + D076
[[📁 Boomerang/Q1#D076|Day 076]]  
> ~🔵 2026-06-01~  

## + D077
[[📁 Boomerang/Q1#D077|Day 077]]  
> ~🟣 2026-06-02~  

## + D078
[[📁 Boomerang/Q1#D078|Day 078]]  
> ~🟠 2026-06-03~  

## + D079
[[📁 Boomerang/Q1#D079|Day 079]]  
> ~🟤 2026-06-04~  

## + D080
[[📁 Boomerang/Q1#D080|Day 080]]  
> ~🌺 2026-06-05~  

## + D081
[[📁 Boomerang/Q1#D081|Day 081]]  
> ~⚫ 2026-06-06~  

## + D082
[[📁 Boomerang/Q1#D082|Day 082]]  
> ~🟢 2026-06-07~  

## + D083
[[📁 Boomerang/Q1#D083|Day 083]]  
> ~🔵 2026-06-08~  

## + D084
[[📁 Boomerang/Q1#D084|Day 084]]  
> ~🟣 2026-06-09~  

## + D085
[[📁 Boomerang/Q1#D085|Day 085]]  
> ~🟠 2026-06-10~  

## + D086
[[📁 Boomerang/Q1#D086|Day 086]]  
> ~🟤 2026-06-11~  

## + D087
[[📁 Boomerang/Q1#D087|Day 087]]  
> ~🌺 2026-06-12~  

## + D088
[[📁 Boomerang/Q1#D088|Day 088]]  
> ~⚫ 2026-06-13~  

## + D089
[[📁 Boomerang/Q1#D089|Day 089]]  
> ~🟢 2026-06-14~  

## + D090
[[📁 Boomerang/Q1#D090|Day 090]]  
> ~🔵 2026-06-15~  

## + D091
[[📁 Boomerang/Q1#D091|Day 091]]  
> ~🟣 2026-06-16~  

