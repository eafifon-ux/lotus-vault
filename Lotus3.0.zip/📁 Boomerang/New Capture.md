# New Capture

| [[📁 Boomerang/Capture|Capture]] | [[📁 Boomerang/To Do|To Do]] |
| -- | -- |