# Seven Behind

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Six Behind|6️⃣🅱️]] | [[📁 Boomerang/Eight Behind|8️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|------------------|--------|
| 1        | 18 |
| 2        | 19 |
| 3        | 20 |
| 4        | 21 |
| 5        | 22 |
| 6        | 23 |
| 7        | 24 |
| 🟡 8     | 1 🟡 |
| 🟡 9     | 2 🟡 |
| 🟡 10    | 3 🟡 |
| 🟡 11    | 4 🟡 |
| 🟡 12    | 5 🟡 |
| 🟡 13    | 6 🟡 |
| 🟡 14    | 7 🟡 |
| 🟡 15    | 8 🟡 |
| 🟡 16    | 9 🟡 |
| 17 💤    | 10 |
| 18 💤    | 11 |
| 19 💤    | 12 |
| 20 💤    | 13 |
| 21 💤    | 14 |
| 22 💤    | 15 |
| 23 💤    | 16 |
| 24 💤    | 💤 17 |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 7        | 24 |
| 8        | 1  |
| 9        | 2  |
| 10       | 3  |
| 11       | 4  |
| 12       | 5  |
| 13       | 6  |
| 🟡 14    | 7 🟡 |
| 🟡 15    | 8 🟡 |
| 🟡 16    | 9 🟡 |
| 🟡 17    | 10 🟡 |
| 🟡 18    | 11 🟡 |
| 🟡 19    | 12 🟡 |
| 🟡 20    | 13 🟡 |
| 🟡 21    | 14 🟡 |
| 🟡 22    | 15 🟡 |
| 23 💤    | 16 |
| 24 💤    | 17 |
| 1 💤     | 18 |
| 2 💤     | 19 |
| 3 💤     | 20 |
| 4 💤     | 21 |
| 5 💤     | 22 |
| 6 💤     | 💤 23 |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)