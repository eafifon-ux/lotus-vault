# Six Behind

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Five Behind|5️⃣🅱️]] | [[📁 Boomerang/Seven Behind|7️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|------------------|--------|
| 1       | 💤 19 |
| 2       | 💤 20 |
| 3       | 💤 21 |
| 4       | 💤 22 |
| 5       | 💤 23 |
| 6       | 💤 24 |
| 🟡 7    | 1 🟡  |
| 🟡 8    | 2 🟡  |
| 🟡 9    | 3 🟡  |
| 🟡 10   | 4 🟡  |
| 🟡 11   | 5 🟡  |
| 🟡 12   | 6 🟡  |
| 🟡 13   | 7 🟡  |
| 🟡 14   | 8 🟡  |
| 🟡 15   | 9 🟡  |
| 🟡 16   | 10 🟡 |
| 17 💤   | 11 |
| 18 💤   | 12 |
| 19 💤   | 13 |
| 20 💤   | 14 |
| 21 💤   | 15 |
| 22 💤   | 16 |
| 23 💤   | 💤 17 |
| 24 💤   | 💤 18 |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 7       | 💤 1  |
| 8       | 💤 2  |
| 9       | 💤 3  |
| 10      | 💤 4  |
| 11      | 💤 5  |
| 12      | 💤 6  |
| 🟡 13   | 7 🟡  |
| 🟡 14   | 8 🟡  |
| 🟡 15   | 9 🟡  |
| 🟡 16   | 10 🟡 |
| 🟡 17   | 11 🟡 |
| 🟡 18   | 12 🟡 |
| 🟡 19   | 13 🟡 |
| 🟡 20   | 14 🟡 |
| 🟡 21   | 15 🟡 |
| 🟡 22   | 16 🟡 |
| 23 💤   | 17    |
| 24 💤   | 18    |
| 1 💤    | 19    |
| 2 💤    | 20    |
| 3 💤    | 21    |
| 4 💤    | 22    |
| 5 💤    | 💤 23    |
| 6 💤    | 💤 24    |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)