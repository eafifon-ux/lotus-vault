# Wealth
Hanokhs dissertation on wealth

> *There are 16 forms of wealth*

## Genetics 
1. Health
2. Beauty
3. Strength
4. Intelligence

## Energy

**5.** Liquid cash
**6.** Assets
**7.** Mobility
**8.** Family

## Network

9. Community
10. Relationships
11. Offspring
12. Spirituality

## Time

**13.** Knowledge
**14.** Courage
**15.** Reputation
**16.** Grain/Time

Hinduism enumerates several lists. This is my list. Some are genetic like beauty and intelligence. Some are inherited and some are earned. America can only offer 5, 6 & 7. Everything else is the trade-off. Some lists include friendliness. What is the point of life if you can't be friendly? I guess friendliness falls under relationships. Grain can also represent time and freedom.

Health is wealth and without it nothing can be enjoyed. Liquid cash is just energy but it's the most superficial idea of wealth. Assets increase in value over time. The surest assets are gold, guns, property & cattle. Freedom is mobility. This is the logic behind boat ownership and EVs. Foreigners that even despise the West seek to live in a G7 nation for the passport alone! 1-4 are genetic. 5-8 are energy. 9-12 are network. 13-16 are related to time. The majority of humans still don't know how a Zettlekasten works so they waste the majority of their time researching the same thing over and over again. Having courage or the ability to be spontaneous is only possible if you can manage your time. A business is reputation and grain represents time and freedom because it can be stored for long durations, giving people the freedom to not have to hunt and forage constantly.