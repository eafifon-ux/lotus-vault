# Capture

[[📁 Boomerang/New Capture|New Capture]]

Take Notes here...