# Capture

| [[📁 Boomerang/New Capture|New Capture]] | [☯️ Balance](https://www.gpc364.com/2025/12/calendar_95.html) |
| -- | -- |

Take Notes here...