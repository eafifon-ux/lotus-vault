# Capture

| [[📁 Boomerang/New Capture|New Capture]] | [[📁 Boomerang/To Do|To Do]] |
| -- | -- |

Take Notes here...