# Thirteen Ahead

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Twelve Ahead|1️⃣2️⃣🅰️]] | [[📁 Boomerang/Fourteen Ahead|1️⃣4️⃣🅰️]] |
| -- | -- |

| Current Location | Juliet |
|------------------|--------|
| 🟡 1  | 14 🟡 |
| 🟡 2  | 15 🟡 |
| 🟡 3  | 16 🟡 |
| 4     | 💤 17 |
| 5     | 💤 18 |
| 6     | 💤 19 |
| 7     | 💤 20 |
| 8     | 💤 21 |
| 9     | 💤 22 |
| 10    | 💤 23 |
| 11    | 💤 24 |
| 🟡 12 | 1 🟡 |
| 🟡 13 | 2 🟡 |
| 🟡 14 | 3 🟡 |
| 🟡 15 | 4 🟡 |
| 🟡 16 | 5 🟡 |
| 17 💤 | 6 |
| 18 💤 | 7 |
| 19 💤 | 8 |
| 20 💤 | 9 |
| 21 💤 | 10 |
| 22 💤 | 11 |
| 23 💤 | 12 |
| 24 💤 | 13 |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 🟡 7  | 20 🟡 |
| 🟡 8  | 21 🟡 |
| 🟡 9  | 22 🟡 |
| 10    | 💤 23 |
| 11    | 💤 24 |
| 12    | 💤 1  |
| 13    | 💤 2  |
| 14    | 💤 3  |
| 15    | 💤 4  |
| 16    | 💤 5  |
| 17    | 💤 6  |
| 🟡 18 | 7 🟡  |
| 🟡 19 | 8 🟡  |
| 🟡 20 | 9 🟡  |
| 🟡 21 | 10 🟡 |
| 🟡 22 | 11 🟡 |
| 23 💤 | 12    |
| 24 💤 | 13    |
| 1 💤  | 14    |
| 2 💤  | 15    |
| 3 💤  | 16    |
| 4 💤  | 17    |
| 5 💤  | 18    |
| 6 💤  | 19    |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)