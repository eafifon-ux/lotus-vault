# Notes

| [[📁 Boomerang/To Do|To Do]] | [[📁 Boomerang/Shopping|Shopping]] |
| --- | --- |

- [[📁 Boomerang/Manual|Manual]]
- [My Moon](https://www.gpc364.com/2026/01/my-moon.html)
- [[📁 Boomerang/Campaign|Campaign]]