# Alefbet



[YouTube](https://youtu.be/c4leWHH-OK0)

- [ ] 𐤀 - transportation  
- [ ] 𐤁  - house  
- [ ] 𐤂  - flip-flops  
- [ ] 𐤃  - Feng Shuei  
- [ ] 𐤄  - Fitness  
- [ ] 𐤅  - magnets  
- [ ] 𐤆  - weapon  
- [ ] 𐤇  - pruning  
- [ ] 𐤈  - case  
- [ ] 𐤉  - tools
- [ ] 𐤊  - garments  
- [ ] 𐤋  - books  
- [ ] 𐤌  - water  
- [ ] 𐤍  - food  
- [ ] 𐤎  - security  
- [ ] 𐤏  - eyes  
- [ ] 𐤐  - words  
- [ ] 𐤑  - addiction/success/trap 
- [ ] 𐤒  - holiness  
- [ ] 𐤓  - calendar
- [ ] 𐤔  - teeth  
- [ ] 𐤕  - covenant/sign