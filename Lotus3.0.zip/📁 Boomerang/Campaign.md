# Campaign
[[📁 Boomerang/To Do|To Do]]

## 🩸 Path of the Eternal Night

*15 quests to rise from a weak fledgling to the Night Lord. Track your progress below.*

| Quest                                      | Points | Date |
|--------------------------------------------|--------|------|
| **Quest 1**           ==blue:[Workout](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest 2**           ==blue:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest 3** ==blue:[[📁 Boomerang/Notes::Language]]==                               | 20     |      |
| **🏆 Lvl 1 – Fledgling of the Night**<br>*Newly turned, weak but awakening to the hunger* | —      | Ascension Achieved    |
| **Quest 4**           ==blue:[Workout](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                                | 10     |      |
| **Quest 5**           ==blue:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                                | 10     |      |
| **Quest 6** ==blue:Language==                                | 20     |      |
| **🏆 Lvl 2 – Blood Initiate**<br>*First taste of true power* | —      | Ascension Achieved    |
| **Quest 7**           ==blue:[Workout](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                                | 10     |      |
| **Quest 8**           ==blue:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                                | 10     |      |
| **Quest 9** ==blue:Language==                                | 20     |      |
| **🏆 Lvl 3 – Shadow Stalker**<br>*Moving unseen, growing in skill and cunning* | —      | Ascension Achieved    |
| **Quest 10**           ==blue:[Workout](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest 11**           ==blue:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest 12** ==blue:Language==                               | 20     |      |
| **🏆 Lvl 4 – Crimson Noble**<br>*Rising in status among the children of the night* | —      | Ascension Achieved    |
| **Quest 13**           ==blue:[Workout](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest 14**           ==blue:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest 15** ==blue:Language==                               | 20     |      |
| **🏆 Lvl 5 – Night Lord**<br>*Master of the eternal dark* | —      | Ascension Achieved    |
| **Quest a**         ==brown:Language==                               | 20     |      |
| **Quest b**     ==brown:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest c**         ==brown:Language==                               | 20     |      |
| **Quest d**     ==brown:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest e**         ==brown:Language==                               | 20     |      |
| **Quest f**     ==brown:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest g**         ==brown:Language==                               | 20     |      |
| **Quest h**     ==brown:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
| **Quest i**         ==brown:Language==                               | 20     |      |
| **Quest j**     ==brown:[Yoga](https://play.google.com/store/apps/details?id=cc.dreamspark.intervaltimer)==                               | 10     |      |
|Remaining::Points Earned|350-@Σ|   |
|Blank::**Quests Completed**|@Count|   |
|Σ:: Points Left|+||

---

### Progress Checkboxes

- [ ] 🏆 **Lvl 1 – Fledgling of the Night**  
  *Newly turned, weak but awakening to the hunger*

- [ ] 🏆 **Lvl 2 – Blood Initiate**  
  *First taste of true power*

- [ ] 🏆 **Lvl 3 – Shadow Stalker**  
  *Moving unseen, growing in skill and cunning*

- [ ] 🏆 **Lvl 4 – Crimson Noble**  
  *Rising in status among the children of the night*

- [ ] 🏆 **Lvl 5 – Night Lord**  
  *Master of the eternal dark*
- [ ] ⚫ **Patala – Deepest realm**  
  *Gaining points without leveling*




