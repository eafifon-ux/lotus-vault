# Campaign

## 🩸 Path of the Eternal Night

*15 quests to rise from a weak fledgling to the Night Lord. Track your progress below.*

| Quest                                      | Points | Date |
|--------------------------------------------|--------|------|
| **Quest 1**                                | 10     |      |
| **Quest 2**                                | 10     |      |
| **Quest 3**                                | 10     |      |
| **🏆 Lvl 1 – Fledgling of the Night**<br>*Newly turned, weak but awakening to the hunger* | —      | —    |
| **Quest 4**                                | 10     |      |
| **Quest 5**                                | 10     |      |
| **Quest 6**                                | 10     |      |
| **🏆 Lvl 2 – Blood Initiate**<br>*First taste of true power* | —      | —    |
| **Quest 7**                                | 10     |      |
| **Quest 8**                                | 10     |      |
| **Quest 9**                                | 10     |      |
| **🏆 Lvl 3 – Shadow Stalker**<br>*Moving unseen, growing in skill and cunning* | —      | —    |
| **Quest 10**                               | 10     |      |
| **Quest 11**                               | 10     |      |
| **Quest 12**                               | 10     |      |
| **🏆 Lvl 4 – Crimson Noble**<br>*Rising in status among the children of the night* | —      | —    |
| **Quest 13**                               | 10     |      |
| **Quest 14**                               | 10     |      |
| **Quest 15**                               | 10     |      |
| **🏆 Lvl 5 – Night Lord**<br>*Master of the eternal dark* | —      | —    |
|Remaining::Points Earned|150-@Σ|   |
|Blank::**Quests Completed**|@Count|   |
|Σ:: Points Left|+||

---

### Progress Checkboxes

- [ ] 🏆 **Lvl 1 – Fledgling of the Night**  
  *Newly turned, weak but awakening to the hunger*

- [ ] 🏆 **Lvl 2 – Blood Initiate**  
  *First taste of true power*

- [ ] 🏆 **Lvl 3 – Shadow Stalker**  
  *Moving unseen, growing in skill and cunning*

- [ ] 🏆 **Lvl 4 – Crimson Noble**  
  *Rising in status among the children of the night*

- [ ] 🏆 **Lvl 5 – Night Lord**  
  *Master of the eternal dark*




