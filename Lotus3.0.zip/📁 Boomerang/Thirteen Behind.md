# Thirteen Behind
[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Twelve Behind|1️⃣2️⃣🅱️]] | [[📁 Boomerang/Fourteen Behind|1️⃣4️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|-----------------|--------|
| 🟡 1    | 12 🟡 |
| 🟡 2    | 13 🟡 |
| 🟡 3    | 14 🟡 |
| 🟡 4    | 15 🟡 |
| 🟡 5    | 16 🟡 |
| 6       | 💤 17 |
| 7       | 💤 18 |
| 8       | 💤 19 |
| 9       | 💤 20 |
| 10      | 💤 21 |
| 11      | 💤 22 |
| 12      | 💤 23 |
| 13      | 💤 24 |
| 🟡 14   | 1 🟡 |
| 🟡 15   | 2 🟡 |
| 🟡 16   | 3 🟡 |
| 17 💤   | 4  |
| 18 💤   | 5  |
| 19 💤   | 6  |
| 20 💤   | 7  |
| 21 💤   | 8  |
| 22 💤   | 9  |
| 23 💤   | 10 |
| 24 💤   | 11 |

## - Musa
| Current Location | Juliet |
|------------------|--------|
| 🟡 7     | 18 🟡 |
| 🟡 8     | 19 🟡 |
| 🟡 9     | 20 🟡 |
| 🟡 10    | 21 🟡 |
| 🟡 11    | 22 🟡 |
| 12       | 💤 23 |
| 13       | 💤 24 |
| 14       | 💤 1  |
| 15       | 💤 2  |
| 16       | 💤 3  |
| 17       | 💤 4  |
| 18       | 💤 5  |
| 19       | 💤 6  |
| 🟡 20    | 7 🟡  |
| 🟡 21    | 8 🟡  |
| 🟡 22    | 9 🟡  |
| 23 💤    | 10    |
| 24 💤    | 11    |
| 1 💤     | 12    |
| 2 💤     | 13    |
| 3 💤     | 14    |
| 4 💤     | 15    |
| 5 💤     | 16    |
| 6 💤     | 17    |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)