# Blank Heptad

| [[📁 Boomerang/Events|Events]] | [[📁 Boomerang/Timeline|Timeline]] | [[📁 Boomerang/🎴Weeks - Heptad|Heptad]] |
| --- | --- | --- |

### Spring
[♣️ 1](https://www.gpc364.com/2025/11/dates_37.html?m=1) ^1^ — 
[[📁 Boomerang/Unspring|♣️ 2]] ^8^ — 
[[📁 Boomerang/Unspring|♣️ 3]] ^15^ — 
[[📁 Boomerang/Unspring|♣️ 4]] ^22^ — 
[[📁 Boomerang/Duspring|♣️ 5]] ^1^ — 
[[📁 Boomerang/Duspring|♣️ 6]] ^8^ — 
[[📁 Boomerang/Duspring|♣️ 7]] ^15^ — 
[[📁 Boomerang/Duspring|♣️ 8]] ^22^ — 
[[📁 Boomerang/Trispring|♣️ 9]] ^1^ — 
[[📁 Boomerang/Trispring|♣️ 10]] ^8^ — 
[[📁 Boomerang/Trispring|♣️ 11]] ^15^ — 
[[📁 Boomerang/Trispring|♣️ 12]] ^22^ — 
[[📁 Boomerang/Trispring|♣️ 13]] ^29^ — 

### Summer
[♦️ 1](https://www.gpc364.com/2025/11/dates_37.html?m=1) ^1^ — 
[[📁 Boomerang/Quadsum|♦️ 2]] ^8^ — 
[[📁 Boomerang/Quadsum|♦️ 3]] ^15^ — 
[[📁 Boomerang/Quadsum|♦️ 4]] ^22^ — 
[[📁 Boomerang/Fivesum|♦️ 5]] ^1^ — 
[[📁 Boomerang/Fivesum|♦️ 6]] ^8^ — 
[[📁 Boomerang/Fivesum|♦️ 7]] ^15^ — 
[[📁 Boomerang/Fivesum|♦️ 8]] ^22^ — 
[[📁 Boomerang/Sixsum|♦️ 9]] ^1^ — 
[[📁 Boomerang/Sixsum|♦️ 10]] ^8^ — 
[[📁 Boomerang/Sixsum|♦️ 11]] ^15^ — 
[[📁 Boomerang/Sixsum|♦️ 12]] ^22^ — 
[[📁 Boomerang/Sixsum|♦️ 13]] ^29^ — 

### Fall
[❤️ 1](https://www.gpc364.com/2025/11/dates_37.html?m=1) ^1^ — "Shoshana"
[[📁 Boomerang/Sepafa|❤️ 2]] ^8^ — 
[[📁 Boomerang/Sepafall|❤️ 3]] ^15^ — 
[[📁 Boomerang/Sepafall|❤️ 4]] ^22^ — 
[[📁 Boomerang/Oktafall|❤️ 5]] ^1^ — 
[[📁 Boomerang/Oktafall|❤️ 6]] ^8^ — 
[[📁 Boomerang/Oktafall|❤️ 7]] ^15^ — 
[[📁 Boomerang/Oktafall|❤️ 8]] ^22^ — 
[[📁 Boomerang/Novafall|❤️ 9]] ^1^ — 
[[📁 Boomerang/Novafall|❤️ 10]] ^8^ — 
[[📁 Boomerang/Novafall|❤️ 11]] ^15^ — 
[[📁 Boomerang/Novafall|❤️ 12]] ^22^ — 
[[📁 Boomerang/Novafall|❤️ 13]] ^29^ — 

### Winter
[♠️ 1](https://www.gpc364.com/2025/11/dates_37.html?m=1) ^1^ — 
[[📁 Boomerang/Dekawint|♠️ 2]] ^8^ — 
[[📁 Boomerang/Dekawint|♠️ 3]] ^15^ — 
[[📁 Boomerang/Dekawint|♠️ 4]] ^22^ — "Lotus"
[[📁 Boomerang/Elvawint|♠️ 5]] ^1^ — 
[[📁 Boomerang/Elvawint|♠️ 6]] ^8^ — 
[[📁 Boomerang/Elvawint|♠️ 7]] ^15^ — 
[[📁 Boomerang/Elvawint|♠️ 8]] ^22^ — 
[[📁 Boomerang/Dozawint|♠️ 9]] ^1^ — 
[[📁 Boomerang/Dozawint|♠️ 10]] ^8^ — 
[[📁 Boomerang/Dozawint|♠️ 11]] ^15^ — 
[[📁 Boomerang/Dozawint|♠️ 12]] ^22^ — 
[[📁 Boomerang/Dozawint|♠️ 13]] ^29^ — 


