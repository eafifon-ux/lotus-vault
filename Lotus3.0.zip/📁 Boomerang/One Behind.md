# One Behind

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Fourteen Ahead|1️⃣4️⃣🅰️]] | [[📁 Boomerang/Two Behind|2️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|-----------------|--------|
| 1       | 💤 24 |
| 🟡 2    | 1 🟡  |
| 🟡 3    | 2 🟡  |
| 🟡 4    | 3 🟡  |
| 🟡 5    | 4 🟡  |
| 🟡 6    | 5 🟡  |
| 🟡 7    | 6 🟡  |
| 🟡 8    | 7 🟡  |
| 🟡 9    | 8 🟡  |
| 🟡 10   | 9 🟡  |
| 🟡 11   | 10 🟡 |
| 🟡 12   | 11 🟡 |
| 🟡 13   | 12 🟡 |
| 🟡 14   | 13 🟡 |
| 🟡 15   | 14 🟡 |
| 🟡 16   | 15 🟡 |
| 17 💤   | 16 |
| 18 💤   | 17 💤 |
| 19 💤   | 18 💤 |
| 20 💤   | 19 💤 |
| 21 💤   | 20 💤 |
| 22 💤   | 21 💤 |
| 23 💤   | 22 💤 |
| 24 💤   | 23 💤 |

## + Musa
| Current Location | Juliet |
|------------------|--------|
| 7       | 💤 5  |
| 🟡 8    | 7 🟡  |
| 🟡 9    | 8 🟡  |
| 🟡 10   | 9 🟡  |
| 🟡 11   | 10 🟡 |
| 🟡 12   | 11 🟡 |
| 🟡 13   | 12 🟡 |
| 🟡 14   | 13 🟡 |
| 🟡 15   | 14 🟡 |
| 🟡 16   | 15 🟡 |
| 🟡 17   | 16 🟡 |
| 🟡 18   | 17 🟡 |
| 🟡 19   | 18 🟡 |
| 🟡 20   | 19 🟡 |
| 🟡 21   | 20 🟡 |
| 🟡 22   | 21 🟡 |
| 23 💤   | 22    |
| 24 💤   | 23 💤 |
| 1 💤    | 24 💤 |
| 2 💤    | 1 💤  |
| 3 💤    | 2 💤  |
| 4 💤    | 3 💤  |
| 5 💤    | 4 💤  |
| 6 💤    | 5 💤  |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## + Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)