# Eight Behind

[[📁 Boomerang/⏹️ Time Block|⏹️ Time Block]]

| [[📁 Boomerang/Seven Behind|7️⃣🅱️]] | [[📁 Boomerang/Nine Behind|9️⃣🅱️]] |
| -- | -- |

| Current Location | Juliet |
|------------------|--------|
| 1        | 💤 17 |
| 2        | 💤 18 |
| 3        | 💤 19 |
| 4        | 💤 20 |
| 5        | 💤 21 |
| 6        | 💤 22 |
| 7        | 💤 23 |
| 8        | 💤 24 |
| 🟡 9     | 1 🟡 |
| 🟡 10    | 2 🟡 |
| 🟡 11    | 3 🟡 |
| 🟡 12    | 4 🟡 |
| 🟡 13    | 5 🟡 |
| 🟡 14    | 6 🟡 |
| 🟡 15    | 7 🟡 |
| 🟡 16    | 8 🟡 |
| 17 💤    | 9  |
| 18 💤    | 10 |
| 19 💤    | 11 |
| 20 💤    | 12 |
| 21 💤    | 13 |
| 22 💤    | 14 |
| 23 💤    | 15 |
| 24 💤    | 16 |

## + Musa
| Current Location | Juliet |
|------------------|--------|
| 7        | 💤 23 |
| 8        | 💤 24 |
| 9        | 💤 1  |
| 10       | 💤 2  |
| 11       | 💤 3  |
| 12       | 💤 4  |
| 13       | 💤 5  |
| 14       | 💤 6  |
| 🟡 15    | 7 🟡  |
| 🟡 16    | 8 🟡  |
| 🟡 17    | 9 🟡  |
| 🟡 18    | 10 🟡 |
| 🟡 19    | 11 🟡 |
| 🟡 20    | 12 🟡 |
| 🟡 21    | 13 🟡 |
| 🟡 22    | 14 🟡 |
| 23 💤    | 15    |
| 24 💤    | 16    |
| 1 💤     | 17    |
| 2 💤     | 18    |
| 3 💤     | 19    |
| 4 💤     | 20    |
| 5 💤     | 21    |
| 6 💤     | 22    |

[🔗 Link](https://www.gpc364.com/2025/11/rethinking-time-introducing-dawn.html)

## Shared Rhythm
> 🟡 = [Shared awake time](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)  
> 💤 = [Sleep / rest](https://www.gpc364.com/2024/09/how-to-use-sun-time.html?m=1)