# To Do

[[📁 Boomerang/Shopping|Shopping]]

### In Progress 
- [ ] water bill

### Waiting
- [ ] Boat

### Back Burner
- [ ] Hawaii 

[[📁 Boomerang/Notes|Notes]]