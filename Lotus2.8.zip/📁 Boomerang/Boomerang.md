# Boomerang

| [[📁 Boomerang/Capture|Capture]] | [[📁 Boomerang/Events|Events]] | [[📁 Boomerang/To Do|ToDo]] | [[📁 Boomerang/Shopping|Shopping]] |
| -- | -- | -- | -- |

| [🗓️ Today](https://www.gpc364.com/p/today.html?m=1) | [☯️ Balance](https://www.gpc364.com/2025/12/calendar_95.html) | [📅 EZDates](https://www.gpc364.com/2026/01/ez-dates.html) | [🌙 Moon](https://www.gpc364.com/2026/01/my-moon.html) |
| --- | --- | --- | --- |

| Q1 | Q2 | Q3 | Q4 |
| -- | -- | -- | -- |
| [[📁 Boomerang/Unspring|🟠 Unspring]] | [[📁 Boomerang/Quadsum|🟠 Quadsum]] | [[📁 Boomerang/Sepafall|🟠 Sepafall]] | [[📁 Boomerang/Dekawint|🟠 Dekawint]] |
| [[📁 Boomerang/Duspring|🌺 Duspring]] | [[📁 Boomerang/Fivesum|🌺 Fivesum]] | [[📁 Boomerang/Oktafall|🌺 Oktafall]] | [[📁 Boomerang/Elvawint|🌺 Elvawint]] |
| [[📁 Boomerang/Trispring|🟢 Trispring]] | [[📁 Boomerang/Sixsum|🟢 Sixsum]] | [[📁 Boomerang/Novafall|🟢 Novafall]] | [[📁 Boomerang/Dozawint|🟢 Dozawint]] |

| **[[📁 Boomerang/1|1]]** | [[📁 Boomerang/2|2]] | [[📁 Boomerang/3|3]] | [[📁 Boomerang/4|4]] | [[📁 Boomerang/5|5]] | [[📁 Boomerang/6|6]] | [[📁 Boomerang/7|7]] |
| -- | -- | -- | -- | -- | -- | -- |
| **[[📁 Boomerang/8|8]]** | [[📁 Boomerang/9|9]] | [[📁 Boomerang/10|10]] | [[📁 Boomerang/11|11]] | [[📁 Boomerang/12|12]] | [[📁 Boomerang/13|13]] | [[📁 Boomerang/14|14]] |
| **[[📁 Boomerang/15|15]]** | [[📁 Boomerang/16|16]] | [[📁 Boomerang/17|17]] | [[📁 Boomerang/18|18]] | [[📁 Boomerang/19|19]] | [[📁 Boomerang/20|20]] | [[📁 Boomerang/21|21]] |
| **[[📁 Boomerang/22|22]]** | [[📁 Boomerang/23|23]] | [[📁 Boomerang/24|24]] | [[📁 Boomerang/25|25]] | [[📁 Boomerang/26|26]] | [[📁 Boomerang/27|27]] | [[📁 Boomerang/28|28]] |
| **[[📁 Boomerang/29|29]]** | [[📁 Boomerang/30|30]] | [[📁 Boomerang/31|31]] | | | | |

